package com.spring.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.DomainClasses.Brand;
import com.spring.DomainClasses.Company;
import com.spring.DomainClasses.User;
import com.spring.Services.BrandService;
import com.spring.Services.CompanyService;
import com.spring.Services.UserService;

@Controller
public class CompanyController {
	@Autowired
	private CompanyService companyService; 
	@Autowired
	private BrandService brandService;
	private Company companyIns = new Company();
	private Brand brandIns = new Brand();
	@RequestMapping("/company/create")
	public String create() {
		return "/company/create";
	}
	@RequestMapping("company/createCompany")
	public String companyCreate(@RequestParam("companyName") String companyName,@RequestParam("brandName")String brandName) {
		String[] a = brandName.split(",");
		companyIns.setCompanyName(companyName);
		companyService.saveCompany(companyIns);
		for(int i=0;i<a.length;i++) {
		brandIns.setBrandName(a[i]);
		System.out.println(a[i]);
		brandIns.setCompany(companyIns);
		brandService.saveBrand(brandIns);
		}
		return "redirect:/brand/list.do";
		
		
	}
	
	@RequestMapping("/company/list")
	public ModelAndView listUsers(Model model) {
		List<Company> companyList = new ArrayList<Company>();
		companyList = companyService.listCompanies();
		model.addAttribute("companyList", companyList);
		return new ModelAndView("/company/list", "companyList", companyList);
	}
	
	

}
