package com.spring.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.DomainClasses.Brand;
import com.spring.DomainClasses.Company;
import com.spring.DomainClasses.User;
import com.spring.Services.BrandService;

@Controller
public class BrandController {
	@Autowired
	private BrandService brandService;
	
	@RequestMapping("/brand/list")
	public ModelAndView listUsers(Model model) {
		List<Brand> brandList = new ArrayList<Brand>();
		brandList = brandService.listBrands();
		model.addAttribute("brandList", brandList);
		return new ModelAndView("/brand/list", "brandList", brandList);
	}
	
	@RequestMapping("/brand/show")
	public ModelAndView showBrand(@RequestParam("brandId") String brandId) {
		Brand brandIns = brandService.getBrandById(Integer.parseInt(brandId));
		return new ModelAndView("/brand/show", "brandIns", brandIns);
	}
	
	@RequestMapping("/brand/edit")
	public ModelAndView edit(@RequestParam("brandId") Integer brandId) {
		Brand brandIns = brandService.getBrandById(brandId);
		return new ModelAndView("/company/create", "brandIns", brandIns);
	}
	
	@RequestMapping("/company/update")
	public ModelAndView updateCompany(@RequestParam("companyName")String companyName,@RequestParam("brandName")String brandName,@RequestParam("brandId") Integer brandId,@RequestParam("companyId")Integer companyId,Model model) {
		Company companyIns = new Company();
		companyIns.setCompanyName(companyName);
		companyIns.setId(companyId);
		Brand brandIns = new Brand();
		brandIns.setId(brandId);
		brandIns.setBrandName(brandName);
		brandIns.setCompany(companyIns);
		Boolean b = brandService.editBrand(brandIns);
		model.addAttribute("message", "Brand Updated Successfully!");
		if(b) {
			return new ModelAndView("/brand/show", "brandIns", brandIns);
		} 
		return null;
		
	}

}
