package com.spring.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.DomainClasses.Brand;
import com.spring.DomainClasses.Category;
import com.spring.DomainClasses.Medicine;
import com.spring.DomainClasses.User;
import com.spring.Services.BrandService;
import com.spring.Services.CategoryService;
import com.spring.Services.MedicineService;

@Controller
public class MedicineController {
	@Autowired
	private MedicineService medicineService; 
	@Autowired
	private BrandService brandService;
	@Autowired
	private CategoryService categoryService;
	@SuppressWarnings("deprecation")
	@RequestMapping("/medicine/create") 
	public ModelAndView create(Model model) {
		List<Brand> brandList = brandService.getAllBrands();
		List<Category> categoryList = categoryService.getAllCategories();
		model.addAttribute("brandList", brandList);
		model.addAttribute("categoryList", categoryList);
		for(Category c:categoryList) {
		}
		return new ModelAndView("medicine/create","brand",model);
	}
	@RequestMapping("/medicine/createMedicine")
	public String createMedicine(@RequestParam("medicineName") String medicineName,@RequestParam("description")String description,
			@RequestParam("actualPrice") Double actualPrice,@RequestParam("discountPrice")Double discountPrice,@RequestParam("quantity")
			Integer quantity,@RequestParam("brandId")Integer brandId,@RequestParam("categoryId")Integer categoryId) {
		Brand brandIns = brandService.getBrandById(brandId);
		Category categoryIns = categoryService.getCategoryById(categoryId);
		Medicine medicineIns = new Medicine(medicineName,description,actualPrice,discountPrice,quantity,brandIns,categoryIns);
		System.out.println("Inside Medicine controller");
		if(medicineService.createMedicine(medicineIns)) {
			return "redirect:/medicine/list.do";
		}
		return "";
	}
	
	@RequestMapping("/medicine/list")
	public ModelAndView listMedicines(Model model) {
		List<Medicine> medicineList = new ArrayList<Medicine>();
		medicineList = medicineService.listMedicines();
		model.addAttribute("medicineList", medicineList);
		return new ModelAndView("/medicine/list", "medicineList", medicineList);
	}
	
	@RequestMapping("/medicine/show")
	public ModelAndView showMedicine(@RequestParam("medicineId") Integer medicineId) {
		Medicine medicineIns = medicineService.getMedicineById(medicineId);
		return new ModelAndView("/medicine/show", "medicineIns", medicineIns);
	}
	

	@RequestMapping("/medicine/edit")
	public ModelAndView edit(@RequestParam("medicineId") Integer medicineId,Model model) {
		Medicine medicineIns = medicineService.getMedicineById(medicineId);
		List<Brand> brandList = brandService.getAllBrands();
		List<Category> categoryList = categoryService.getAllCategories();
		model.addAttribute("brandList", brandList);
		model.addAttribute("categoryList", categoryList);
		return new ModelAndView("/medicine/create", "medicineIns", medicineIns);
	}
	
	@RequestMapping("/medicine/update")
	public ModelAndView updateMedicine(@RequestParam("medicineName") String medicineName,@RequestParam("description")String description,
	@RequestParam("actualPrice") Double actualPrice,@RequestParam("discountPrice")Double discountPrice,@RequestParam("quantity")
	Integer quantity,@RequestParam("brandId")Integer brandId,@RequestParam("categoryId")Integer categoryId,Model model,
	@RequestParam("medicineId")Integer medicineId) {
		Brand brandIns = brandService.getBrandById(brandId);
		Category categoryIns = categoryService.getCategoryById(categoryId);
		Medicine medicineIns = new Medicine(medicineId,medicineName,description,actualPrice,discountPrice,quantity,brandIns,categoryIns);

		Boolean b = medicineService.editMedicine(medicineIns);
		model.addAttribute("message", "Medicine Details Updated Successfully!");
		if(b) {
			return new ModelAndView("/medicine/show", "medicineIns", medicineIns);
		} 
		return null;
		
	}


}
