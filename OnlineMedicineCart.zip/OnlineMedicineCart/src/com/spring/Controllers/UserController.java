package com.spring.Controllers;

import com.spring.DomainClasses.User;
import com.spring.Services.*;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {

	@Autowired
	private UserService userService;
	private User userIns = new User();

	@RequestMapping("/index")
	public String index() {
		return "/user/index";
	}

	@RequestMapping("/login")
	public String login() {
		return "/user/login";
	}

	@RequestMapping("/signup")
	public String signup() {
		return "/user/signup";
	}

	@RequestMapping("/signinUser")
	public String signinUser(@ModelAttribute("user") User userIns) {
		userService.saveUser(userIns);
		return "";
	}

	@RequestMapping("/loginUser")
	public String loginUser(@RequestParam("userName") String userName, @RequestParam("password") String password) {
		userIns.setUserName(userName);
		userIns.setPassword(password);
		if (userService.checkUserExist(userIns) != null) {
			return "/user/index";
		}
		return "/user/login";
	}

	@RequestMapping("/user/list")
	public ModelAndView listUsers(Model model) {
		List<User> userList = new ArrayList<User>();
		userList = userService.listUsers();
		model.addAttribute("userList", userList);
		return new ModelAndView("/user/list", "userList", userList);
	}

	@RequestMapping("/user/show")
	public ModelAndView showUser(@RequestParam("userId") String userId) {
		User userIns = userService.getUserById(Integer.parseInt(userId));
		return new ModelAndView("/user/show", "userIns", userIns);
	}

	@RequestMapping("/user/edit")
	public ModelAndView edit(@RequestParam("userId") Integer userId) {
		User userIns = userService.getUserById(userId);
		return new ModelAndView("/user/signup", "userIns", userIns);
	}
	
	@RequestMapping("/user/update")
	public ModelAndView updateUser(@ModelAttribute("user")User userIns,Model model) {
		Boolean b = userService.editUser(userIns);
		model.addAttribute("message", "User Updated Successfully!");
		if(b) {
			return new ModelAndView("/user/show", "userIns", userIns);
		} 
		return null;
		
	}

}
