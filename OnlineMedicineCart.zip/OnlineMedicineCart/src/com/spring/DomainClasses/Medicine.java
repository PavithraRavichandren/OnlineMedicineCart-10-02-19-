package com.spring.DomainClasses;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "Medicine")
public class Medicine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	@Column(name="medicineName")
	private String medicineName;
	@Column(name="description")
	private String description;
	@Column(name="actualPrice")
	private Double actualPrice;
	@Column(name="discountPrice")
	private Double discountPrice;
	@Column(name="quantity")
	private Integer quantity;
	@ManyToOne
	@ForeignKey(name = "brand")
	@Autowired
	private Brand brand;
	@ManyToOne
	@ForeignKey(name = "category")
	@Autowired
	private Category category;
	public Medicine() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Medicine(Integer id, String medicineName, String description, Double actualPrice, Double discountPrice,
			Integer quantity, Brand brand) {
		super();
		this.id = id;
		this.medicineName = medicineName;
		this.description = description;
		this.actualPrice = actualPrice;
		this.discountPrice = discountPrice;
		this.quantity = quantity;
		this.brand = brand;
	}
	public Medicine(String medicineName, String description, Double actualPrice, Double discountPrice, Integer quantity,
			Brand brand, Category category) {
		super();
		this.medicineName = medicineName;
		this.description = description;
		this.actualPrice = actualPrice;
		this.discountPrice = discountPrice;
		this.quantity = quantity;
		this.brand = brand;
		this.category = category;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(Double actualPrice) {
		this.actualPrice = actualPrice;
	}
	public Double getDiscountPrice() {
		return discountPrice;
	}
	public void setDiscountPrice(Double discountPrice) {
		this.discountPrice = discountPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Brand getBrand() {
		return brand;
	}
	public void setBrand(Brand brand) {
		this.brand = brand;
	}
	public Medicine(Integer id, String medicineName, String description, Double actualPrice, Double discountPrice,
			Integer quantity, Brand brand, Category category) {
		super();
		this.id = id;
		this.medicineName = medicineName;
		this.description = description;
		this.actualPrice = actualPrice;
		this.discountPrice = discountPrice;
		this.quantity = quantity;
		this.brand = brand;
		this.category = category;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
}
